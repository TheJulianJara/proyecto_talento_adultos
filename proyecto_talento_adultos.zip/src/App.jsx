import React from 'react';
import './App.css'

function App() {

  return (
    <>
    <p className=''>Hola</p>
    </>
  )
}

export default App
