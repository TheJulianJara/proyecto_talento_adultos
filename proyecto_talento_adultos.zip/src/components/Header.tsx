export default function Header() {
  return(
    <>
      <h1>Header</h1>
    </>
  )
}